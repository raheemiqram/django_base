def core(request):
    context = {
        "SITE_NAME": "DJANGO_DASHBOARD",
    }
    return context
